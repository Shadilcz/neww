#!/bin/bash
service tomcat start